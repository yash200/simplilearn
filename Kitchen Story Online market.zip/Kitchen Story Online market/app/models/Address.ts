export class Address{
  streetNumber:number;
  streetName:string;
  suite:string;
  city:string;
  state:string;
  country:string;
  zipcode:string;
}
