package com.sportyshoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportyShoesBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
