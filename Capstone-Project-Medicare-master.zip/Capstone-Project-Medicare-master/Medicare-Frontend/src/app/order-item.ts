export class OrderItem {
    pid!: number;
    quantity!: number;
}