import { User } from "./user";

export class Complaint {

        category: string;
		heading: string;
		details:string;
		address:string;
		pincode:string;
		fullname:string;
		complaintStatus:string;
		customer:User;
		
}
