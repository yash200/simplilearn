import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engineer-home',
  templateUrl: './engineer-home.component.html',
  styleUrls: ['./engineer-home.component.css']
})
export class EngineerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
